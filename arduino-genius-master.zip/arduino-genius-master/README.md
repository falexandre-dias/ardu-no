# Projeto - Jogo GENIUS com arduino
GENIUS é um jogo de memória que se tornou popular na década de 80. O objetivo do jogo é acompanhar uma sequência de luzes e sons sem errar. Este projeto ensina passo a passo a desenvolver este jogo no arduino.

[![genius arduino](http://img.youtube.com/vi/gYgGgox5Q4o/0.jpg)](http://www.youtube.com/watch?v=gYgGgox5Q4o "arduino genius")
